import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Etch_aSketch_Keyboard extends PApplet {

//global var
int x, y;

public void setup() {
  size(400,400);
  frameRate(10);
  // initializing start coords
  x = 200;
  y = 200;
  frameRate(100);
}

public void draw() {
  fill(255);
  stroke(random(255), random(255), random(255) );
 // drawName();
  //noLoop();
}

public void keyPressed() {
  if( key == CODED) {
     if(keyCode == RIGHT) {
      moveRight(1);
    } else if (keyCode == DOWN) {
      moveDown(1);
    } else if (keyCode == UP) {
      moveUp(1);
    } else if (keyCode == LEFT) {
      moveLeft(1);
    }
  }
}

public void mouseClicked() {
  
  saveFrame("line-######.png");
}

// Algorithm for your first name
public void drawName() {
  moveRight(16);
  moveLeft(8);
  moveDown(15);
  moveLeft(7);
  moveUp(3);
  moveDown(3);
  moveRight(7);
  moveUp(15);
  moveRight(17);
  moveDown(15);
  moveRight(7);

}

// Method to draw right line
public void moveRight(int rep) {
  for(int i=0;i<rep*10;i++){
    point(x+i,y);
  }
  x=x+(10*rep);
}

public void moveLeft(int rep) {
  for( int i= 0;  -i < rep*10; i--){
    point(x+i, y);
  }
  x=x-(10*rep);
}

public void moveDown(int rep) {
  for( int i= 0; i < rep* 10; i++) {
    point(x, y+i);
  }
  y=y + (10*rep);
}

public void moveUp(int rep) {
  for ( int i = 0; i < rep* 10; i++) {
    point(x, y - i);
  }
  y= y - ( 10*rep);
}

public void rightDown( int rep) {
  for (int i = 0; i < rep*10; i++) {
    point(x + i, y + i);
  }
  y= x -(10*rep);
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Etch_aSketch_Keyboard" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
