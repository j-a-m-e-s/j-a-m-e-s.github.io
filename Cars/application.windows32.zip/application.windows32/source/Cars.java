import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Cars extends PApplet {

Car myCar;
Car myCar2;
Car[] myCars = new Car[250];

public void setup() {
  int i;
  size(1000, 1000);
  for (i =0; i < 250; i=i+1) {
    myCars[i] = new Car(PApplet.parseInt(random(0, width)), PApplet.parseInt(random(0, height)), PApplet.parseInt(random(1,20)), color(random(255), random(255), random(255)));
  }
}

public void draw() {
  int i;
  background(255);
  for (i=0; i < 250; i=i+1) {
    myCars[i].display();
    myCars[i].drive();
  }
}
class Car {
  //Member Variable
  int xpos, ypos, cSpeed, direction, cwidth, cheight, cdiameter;
  int cColor;

  //contructor
  Car(int tempX, int tempY) {
    xpos = tempX;
    ypos = tempY;
    cSpeed = PApplet.parseInt(random(5, cdiameter));
    cwidth = 50;
    cheight = 30;
    cdiameter = 15;
    cColor = color(random(255), random(255), random(255));
    if (random( -1, 1) > 0) {
      direction =1;
    } else {
      direction = -1;
    }
  }


  //constructor #2
  Car (int tempX, int tempY, int tempSpeed, int tempColor) {
    xpos = tempX;
    ypos = tempY;
    cSpeed = tempSpeed;
    cColor = tempColor;
    cwidth = 50;
    cheight = 30;
    cdiameter = 15;
    if (random( -1, 1) > 0) {
      direction =1;
    } else {
      direction = -1;
    }
  }

  //member Methods
  public void display() {
    rectMode(CENTER);
    fill(cColor);
    rect(xpos, ypos, cwidth, cheight, cheight/3, cwidth, 0, cheight/6);
    fill(200);
    ellipse(xpos - cdiameter, ypos + cdiameter, cdiameter, cdiameter);
    ellipse(xpos + cdiameter, ypos + cdiameter, cdiameter, cdiameter);
    fill(0);
    ellipse(xpos - cdiameter, ypos + cdiameter, 5, 5);
    ellipse(xpos + cdiameter, ypos + cdiameter, 5, 5);
    line(xpos + cdiameter, ypos- (cheight - 3), xpos+cdiameter, ypos - 12);
    fill(random(103, 153));
    ellipse(xpos + cdiameter, ypos - (cheight - 3), 3, 3);
    fill(255, 0, 0);
    ellipse(xpos - 22, ypos + 7, 5, 5);
    fill(0, 170, 255);
    rect(xpos - 7, ypos, (cheight/3), (cheight/3));
    rect(xpos + 7, ypos, (cheight/3), (cheight/3));
    fill(255, 255, 0);
    rect(xpos + 23, ypos + 7, 5, 5);
  }

  public void drive() {
    xpos = xpos + direction*cSpeed;
    if ( xpos > width) {
      xpos = 0;
    }
    if (xpos < 0) {
      xpos = width;
    }
  }
}



  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Cars" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
