#include <iostream>
#include "makeBox.h"
using namespace std;

int main( )
{
   Box Box1;               
                
 float volume;
 float surfaceArea;
 
   float height;
  cout << "What is the height of the box?" << endl;
  cin >> height;
 
   float width;
  cout << "What is the width of the box?" << endl;
  cin >> width;

  float length;
   cout << "What is the length of the box?" << endl;
   cin >> length;

   
   volume = Box1.Area(length, width, height);
   surfaceArea = Box1.Surface(length, width, height);
  cout << "Volume of Box: " << volume << endl;
  cout << "Surface area of box: " << surfaceArea << endl; 
return 0;
}

////////////////////////////
// Fancy Comment is Fancy //
////////////////////////////
