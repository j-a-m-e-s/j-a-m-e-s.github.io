
class Box
{
 
   public:
    
     float Area(float length, float width, float height)
     {
     return length*width*height;
     }
     
     float Surface(float length, float width, float height)
     {
      return ((length * width) + (width * height) + (height * length)) * 2;
     }
   };
