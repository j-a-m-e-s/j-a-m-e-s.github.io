#include <iostream>		
#include "sword.h"
#include "streng.h"
#include "reach.h"

using namespace std;

int main() {
	weap streng;
	weap reach;


float sharp;
float weight;
float leng;
float width;
float r;
float s;



cout << "How sharp is your sword from a scale of 1-100?" << endl;
cin >> sharp;

cout << "How much does the sword weigh in pounds?" << endl;
cin >> weight;

cout << "What is the length of your Sword in inches?" << endl;
cin >> leng;

cout << "How wide is your sword in inches?" << endl;
cin >> width;

r = reach.calcReach(leng, width);
s = streng.calcStreng(sharp, weight);

cout <<"The sharpness of your sword is: "  << sharp << endl;
cout <<"Your sword weighs: "  << weight << " pounds." << endl;
cout <<"Your sword is: "  << leng << " inches long." << endl;
cout <<"Your sword is: "  << width << " incheswide." <<endl;

cout << "Your sword's power level is: " << s << endl;
cout << "Your Sword's reach is: " << r << endl;

cout << "The quality of your sword is: " << s*r/10 << endl;

if (s*r/10 > 9000)
cout << "Its over 9000!!!!!!!!!!!!!!!!" << endl; 
else {
	cout << "Thats a pretty good sword." << endl;
}
}

