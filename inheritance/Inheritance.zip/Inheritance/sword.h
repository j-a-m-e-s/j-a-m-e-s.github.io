
class weap {	

public:	
		
float leng;
float width;	
float sharp;
float weight;


float	calcStreng(float sharp, float weight)
	{		
return	sharp*weight;		
}

float calcReach(float leng, float width)
	{		
return leng * width;		
}

};	
