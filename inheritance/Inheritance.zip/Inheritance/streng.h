class streng: public weap {
	public:
		float calcStreng() {
			return  (sharp* weight* 100);
		}
};
