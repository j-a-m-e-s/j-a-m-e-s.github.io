class reach: public weap {
public:
float calcReach() {
return(leng+width/5);
}
};
